import json

def process_data(data):
    name = data["name"]
    print(name)
    message = f"Hello {name}"
    return { "message": message }

